# DiGRATex
This is a LaTeX style file for the DiGRA conference.

There is an associated Overleaf project and the two are utilized as such https://ineed.coffee/3454/how-to-synchronize-an-overleaf-latex-paper-with-a-github-repository/ .

This uses fontspec for the Arial font, which means you can't use pdflatex as your tex compiler.
